<?php

// Load autoloader
require 'vendor/autoload.php';

// Load bootstrap
require 'core/bootstrap.php';
