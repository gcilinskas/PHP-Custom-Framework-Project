<?php

namespace App\Helpers;

class StoreProduct
{

    protected $request;

    public function __construct($request)
    {
        $this->requeset = $request;
    }

    public function store()
    {
        
    }
}